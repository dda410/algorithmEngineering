#!/bin/bash
java -cp ./ Main $1
