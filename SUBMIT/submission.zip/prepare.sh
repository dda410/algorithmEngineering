#!/bin/bash
javac *.java
